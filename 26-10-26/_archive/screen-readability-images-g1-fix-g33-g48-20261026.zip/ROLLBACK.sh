#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then echo 'Usage: ROLLBACK.sh ARCHIVE.zip OUTPUT_COPY.png'; exit 2; fi
python3 - "$1" "$2" <<'PY_RESTORE'
from pathlib import Path
from zipfile import ZipFile
import sys,hashlib
archive=Path(sys.argv[1]);out=Path(sys.argv[2])
with ZipFile(archive) as z:data=z.read('grey-1-before.png')
out.write_bytes(data)
print('ROLLBACK PASS: '+hashlib.sha256(out.read_bytes()).hexdigest())
PY_RESTORE
