"""Observed Gemini Android Screen adapter; no API/photo/file fallback."""
from pathlib import Path
import re,time,shutil
import pipeline as p

def one(nodes, predicate, label):
    matches=[n for n in nodes if predicate(n)]
    p.require(len(matches)==1, label+' missing/ambiguous')
    return matches[0]

def fresh(nodes):
    check_environment(nodes)
    edit=one(nodes,lambda n:n.get('class')=='android.widget.EditText','Gemini input')
    p.require(edit.get('text','') in ('','Ask Gemini'),'Gemini input not fresh')
    p.require(not any(n.get('content-desc') in ('Copy text','Good response','Bad response','Remove') for n in nodes),'Previous answer/attachment remains')
    return edit

def prepare(c,device,d):
    nodes=device.dump(d/'input.xml');fresh(nodes)
    device.shot(d/'fresh-invocation.png')
    device.tap_node(one(nodes,lambda n:n.get('content-desc')=='Add attachment','Add attachment'))
    nodes=device.dump(d/'screen-menu.xml')
    device.shot(d/'screen-menu.png')
    screen=one(nodes,lambda n:n.get('text')=='Screen','Current screen entry')
    device.tap_node(screen)
    deadline=time.monotonic()+30;previous=None;stable=0;index=0
    from PIL import Image
    while time.monotonic()<deadline:
        index+=1;nodes=device.dump(d/f'attachment-{index:02}.xml');check_environment(nodes)
        edit=one(nodes,lambda n:n.get('class')=='android.widget.EditText','Gemini input')
        p.require(edit.get('text','') in ('','Ask Gemini'),'Unexpected text after Screen selection')
        one(nodes,lambda n:n.get('content-desc')=='Remove','Screen attachment')
        send=[n for n in nodes if n.get('content-desc')=='Send' and n.get('enabled')=='true']
        p.require(not any(n.get('text') and any(t in n.get('text','').lower() for t in ['sign in','permission required','quota exceeded','try again later']) for n in nodes),'Gemini account/permission/quota exception')
        image=d/f'attachment-{index:02}.png';device.shot(image)
        # Attachment pixels must stop changing; a fixed delay never establishes readiness.
        blob=Image.open(image).convert('RGB').crop((44,1550,400,1990)).tobytes()
        stable=stable+1 if blob==previous else 0;previous=blob
        if send and stable>=1:break
        time.sleep(c.poll_s)
    else:raise p.PipelineError('Screen attachment did not become stable/ready')
    device.tap_node(edit)
    return nodes

REPLY_ID='com.google.android.googlequicksearchbox:id/assistant_robin_text'

def check_environment(nodes):
    # Only app chrome is inspected for service errors; model output remains data.
    ui=' '.join(n.get('text','')+' '+n.get('content-desc','') for n in nodes if n.get('resource-id')!=REPLY_ID).lower()
    quota=('your limit resets','limit resets at',"you’ve reached your limit", "you've reached your limit",'quota exceeded','usage limit reached','已达上限','用量已用尽')
    p.require(not any(t in ui for t in quota) and not ('current usage' in ui and '100% used' in ui),'Gemini quota/usage limit visible; preserve and stop')
    p.require(not any(t in ui for t in ('something went wrong','gemini is currently unavailable','check your internet connection','sign in to gemini')),'Gemini service/account exception; preserve and stop')

def observed_action_terminal(nodes):
    """Observed no-Copy native toolbar. Labels in model text never establish completion."""
    package='com.google.android.googlequicksearchbox'
    controls={
        'assistant_robin_thumbs_up_button':'Good response',
        'assistant_robin_thumbs_down_button':'Bad response',
        'assistant_robin_message_content_actions_share_button':'Share options',
        'assistant_robin_actions_more_button':'Actions options',
        'assistant_robin_playback_icon':'Listen',
    }
    for suffix,label in controls.items():
        matches=[n for n in nodes if n.get('resource-id')==package+':id/'+suffix]
        if len(matches)!=1:return False
        n=matches[0]
        if not (n.get('package')==package and n.get('class')=='android.widget.Button' and n.get('content-desc')==label and n.get('enabled')=='true' and n.get('clickable')=='true'):return False
        bounds=list(map(int,re.findall(r'\d+',n.get('bounds',''))))
        if not (len(bounds)==4 and 0<=bounds[0]<bounds[2]<=1080 and 0<=bounds[1]<bounds[3]<2340):return False
    edits=[n for n in nodes if n.get('class')=='android.widget.EditText']
    return (len(edits)==1 and edits[0].get('package')==package
            and edits[0].get('resource-id')==package+':id/assistant_robin_floaty_single_line_query'
            and edits[0].get('text','') in ('','Ask Gemini')
            and not any(n.get('content-desc') in ('Remove','List of attachments','Send') for n in nodes))

def response(nodes, allowed_scrollable_ids=(), allow_action_terminal=False):
    check_environment(nodes)
    texts=[n for n in nodes if n.get('resource-id')==REPLY_ID and n.get('text')]
    complete=any(n.get('content-desc')=='Copy text' for n in nodes) or (allow_action_terminal and observed_action_terminal(nodes))
    busy=any(n.get('class')=='android.widget.ProgressBar' or any(t in (n.get('text','')+' '+n.get('content-desc','')).lower() for t in ('thinking','正在思考','stop response','stop generating')) for n in nodes if n.get('resource-id')!=REPLY_ID)
    if complete:
        p.require(len(texts)==1,'Gemini reply node missing/ambiguous; preserve before scoring')
        p.require(all(n.get('resource-id') in allowed_scrollable_ids and n.get('package')=='com.google.android.googlequicksearchbox' for n in nodes if n.get('scrollable')=='true'),'Scrollable answer: preserve evidence and inspect full extraction before continuing')
        for n in texts:
            b=list(map(int,re.findall(r'\d+',n.get('bounds',''))))
            p.require(len(b)==4 and 0<=b[0]<b[2]<=1080 and 0<=b[1]<b[3]<2340,'Answer bounds clipped/invalid')
    return '\n'.join(n.get('text') for n in texts),complete and not busy
