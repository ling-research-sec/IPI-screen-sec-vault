"""Automatic context only. Explicit attachment taps are forbidden by Device guard."""
from pathlib import Path
import shutil,time,re
from PIL import Image,ImageChops
import pipeline as p
import gemini_adapter as base
DISCLOSURE='Gemini checked your screen and app info to give you more relevant answers. You can turn this off for future responses in Settings.'
SEPARATOR='\n\u200b\n\u200b'

def prepare(c,device,d):
 nodes=device.dump(d/'input.xml');edit=base.fresh(nodes);device.shot(d/'fresh-invocation-no-attachment.png');device.tap_node(edit)

def prompt_ready(c,device,d,nodes):
 base.check_environment(nodes)
 p.require(not any(n.get('content-desc') in ('Remove','List of attachments') for n in nodes),'Explicit attachment present: automatic route must stop')
 if any(n.get('package') in ('com.android.inputmethod.latin','org.fcitx.fcitx5.android') for n in nodes):
  shutil.copy2(d/'prompt.xml',d/'prompt-before-keyboard-hide.xml');device.shell('input','keyevent','4');device.check_component(c.ui['assistant_activity']);nodes=device.dump(d/'prompt.xml')
 edits=[n for n in nodes if n.get('class')=='android.widget.EditText'];p.require(len(edits)==1 and edits[0].get('text')==c.prompt,'Prompt changed when hiding keyboard')
 p.require(not any(n.get('content-desc') in ('Remove','List of attachments') for n in nodes),'Manual attachment appeared')
 base.check_environment(nodes);return nodes

def response(nodes):
 full,complete=base.response(nodes,allowed_scrollable_ids=('com.google.android.googlequicksearchbox:id/assistant_robin_floaty_scrollable_area',),allow_action_terminal=True);body=full;disclosure=None
 # Exact app-owned context notice boundary verified in real Pro probe XML and rendered UI.
 # Keep full UI text separately; never trim arbitrary prose, letters, errors or explanations.
 suffix=SEPARATOR+DISCLOSURE
 if full.endswith(suffix):body=full[:-len(suffix)];disclosure=DISCLOSURE
 elif DISCLOSURE in full:raise p.PipelineError('Unrecognized context-notice boundary; preserve full UI before scoring')
 return body,complete,dict(requires_full_reply_validation=any(n.get('scrollable')=='true' for n in nodes),ui_full_response=full,context_disclosure=disclosure,extraction_rule='Pinned reply node; exact terminal app-context disclosure separated; all raw UI retained')

def verify_long_reply(c,device,d,metadata,n,v):
    expected=metadata['ui_full_response'];folder=d/'long-reply';folder.mkdir();deadline=time.monotonic()+90;previous=None;same=0;pages=[]
    def snapshot(index,swipe):
        nodes=device.dump(folder/f'{index:02}.xml');body,complete,meta=response(nodes)
        p.require(complete and meta['ui_full_response']==expected,'Scrollable reply changed or virtualized; preserve before scoring')
        area=base.one(nodes,lambda x:x.get('resource-id')=='com.google.android.googlequicksearchbox:id/assistant_robin_floaty_scrollable_area','Known reply scroll area')
        reply=base.one(nodes,lambda x:x.get('resource-id')==base.REPLY_ID,'Full reply node')
        rect=list(map(int,re.findall(r'\d+',area.get('bounds',''))));bounds=list(map(int,re.findall(r'\d+',reply.get('bounds',''))))
        path=c.evidence(n)/'screenshots'/f'{c.stem}-screenshot-{v}-long-{index:02}.png';device.shot(path);pages.append(dict(path=str(path.relative_to(c.evidence(n))),sha256=p.file_hash(path),xml_member=str((folder/f'{index:02}.xml').relative_to(c.work)),swipe_before=swipe))
        crop=Image.open(path).convert('RGB').crop(tuple(rect));return meta,rect,bounds,crop
    meta,rect,bounds,previous=snapshot(0,False)
    for index in range(1,21):
        p.require(time.monotonic()<deadline,'Long reply verification timeout; preserve, not score')
        device.check_component(c.ui['assistant_activity']);x=(bounds[0]+bounds[2])//2;y1=min(bounds[3]-70,rect[3]-150);y2=max(bounds[1]+80,rect[1]+80);p.require(y1-y2>150,'Reply readback viewport too small')
        device.shell('input','swipe',x,y1,x,y2,300);time.sleep(.3);meta,rect,bounds,actual=snapshot(index,True);equal=actual.size==previous.size and ImageChops.difference(previous,actual).getbbox() is None;same=same+1 if equal else 0;previous=actual
        if same>=2:
            proof=dict(status='PASS',ui_full_sha256=p.digest(expected.encode()),full_text_unchanged_across_viewports=True,bottom_view_stable_twice=True,evidence_screenshots=pages,manual_attachment_actions=0)
            p.save_json(folder/'verification.json',proof);meta.update(long_reply_verified=True,long_reply_proof_member=str((folder/'verification.json').relative_to(c.work)));return meta
    raise p.PipelineError('Long reply bottom not verified; no score written')
